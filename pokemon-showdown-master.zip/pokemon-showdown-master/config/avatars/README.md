# Custom avatars directory

You can give your users custom avatars. Your server *must* be registered, or this won't work.

Put avatar files (80x80 PNG files) here, and then use the `/addavatar` command to give users access to them.
